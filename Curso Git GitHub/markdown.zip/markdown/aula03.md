# Citação

> Geek University
> sfsdfsdfsdfsdf
> adfsadfasdfsa

# Lista Não Ordenada

- Manga
  - Verde
- Uva
  - Argentina
  - Venezuelana
- Laranja

Outra forma

* Manga
  * Verde
* Uva
  * Argentina
  * Venezuelana
* Laranja

# Listas Ordenadas

1. Manga
  1.1. Verde
2. Uva
  2.1. Argentina
  2.2. Venezuelana
3. Laranja

# Lista O Automática

1. Manga
  1.1. Verde
1. Uva
  2.1. Argentina
  2.2. Venezuelana
1. Laranja

# Imagens Locais

![Geek](rubik.png)

# Imagens da Web

![Outra](https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTGdT-eZmokw7OoF7COwVB_gRRvIumRXYhWsGD-KZkbTKc5Bz19&usqp=CAU)

