# Lista de tarefas

- [ ] Acordar
- [ ] Escovar os dentes
- [x] Tomar banho
- [x] ~~Tomar café da manhã~~

![Outra][geek]

~~Este texto está riscado~~

# Separar conteúdo

---

# Referências

[Curso de Linux][curso]

![Imagem][geek]


[geek]: rubik.png

[curso]: https://www.udemy.com/course/curso-de-linux-completo-para-usuario-comum-ou-desenvolvedor/?referralCode=430246ED65FFF415A067
