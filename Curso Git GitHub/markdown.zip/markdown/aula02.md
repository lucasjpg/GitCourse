# Itálico

Estava estudando inglês com _the books is on the table_ ontem.

# Strong/Bold

Fiz o curso de Git na **Geek University**

# Outra forma

__Geek University__ tem os *melhores* cursos.

# Links

[Geek University](https://www.geekuniversity.com.br "Website da Geek University")

<https://www.geekuniversity.com.br>

<contato@geekuniversity.com.br>

